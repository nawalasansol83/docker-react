# Azure AD B2C Custom Policy Node Sample

This is a minimal Express server that signs users in with an Azure AD B2C custom policy using `@azure/msal-node`.

## Run

```powershell
npm install
npm start
```

Open:

```text
http://localhost:3000
```

## Azure app registration checklist

Make sure the web app registration has this redirect URI:

```text
http://localhost:3000/redirect
```

The sample uses this policy authority:

```text
https://symcorhermesdev.b2clogin.com/symcorhermesdev.onmicrosoft.com/b2c_1a_v2_signin_emailmfa
```

If your policy name casing differs in Azure, update `B2C_POLICY` in `.env`.
